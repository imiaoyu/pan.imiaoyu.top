package com.imiaoyu.pan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
